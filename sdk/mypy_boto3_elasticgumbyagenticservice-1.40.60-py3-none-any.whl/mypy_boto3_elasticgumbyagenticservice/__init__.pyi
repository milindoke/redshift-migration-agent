"""
Main interface for elasticgumbyagenticservice service.

Usage::

    ```python
    import boto3
    from mypy_boto3_elasticgumbyagenticservice import (
        Client,
        ElasticgumbyagenticserviceClient,
        ListAgentInstancesPaginator,
        ListArtifactsPaginator,
        ListHitlTasksPaginator,
        ListJobPlanStepsPaginator,
    )

    session = boto3.Session()

    client: ElasticgumbyagenticserviceClient = boto3.client("elasticgumbyagenticservice")
    session_client: ElasticgumbyagenticserviceClient = session.client("elasticgumbyagenticservice")

    list_agent_instances_paginator: ListAgentInstancesPaginator = client.get_paginator("list_agent_instances")
    list_artifacts_paginator: ListArtifactsPaginator = client.get_paginator("list_artifacts")
    list_hitl_tasks_paginator: ListHitlTasksPaginator = client.get_paginator("list_hitl_tasks")
    list_job_plan_steps_paginator: ListJobPlanStepsPaginator = client.get_paginator("list_job_plan_steps")
    ```
"""

from .client import ElasticgumbyagenticserviceClient
from .paginator import (
    ListAgentInstancesPaginator,
    ListArtifactsPaginator,
    ListHitlTasksPaginator,
    ListJobPlanStepsPaginator,
)

Client = ElasticgumbyagenticserviceClient

__all__ = (
    "Client",
    "ElasticgumbyagenticserviceClient",
    "ListAgentInstancesPaginator",
    "ListArtifactsPaginator",
    "ListHitlTasksPaginator",
    "ListJobPlanStepsPaginator",
)
