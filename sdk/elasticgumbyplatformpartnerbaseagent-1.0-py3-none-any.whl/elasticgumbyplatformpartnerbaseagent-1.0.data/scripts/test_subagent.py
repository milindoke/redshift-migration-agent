#!python

import logging

from eg_platform_base_agent.subagent_cli import run_main

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    run_main()
