"""
FastAPI server for the ATX Base Subagent
"""

import asyncio
import json
import logging
from typing import Dict

import uvicorn
from fastapi import Depends, FastAPI, HTTPException

from eg_platform_base_agent.base_subagent.base_subagent import BaseSubagent
from eg_platform_base_agent.custom_types.common_types import (
    A2AError,
    A2AErrorCode,
    InvocationRequest,
)
from eg_platform_base_agent.custom_types.response_types import SendMessageOutput
from eg_platform_base_agent.utils import (
    convert_subagent_response_to_send_message_output,
    extract_message_info,
    extract_text_from_strands_agent_response,
)

logger = logging.getLogger(__name__)

app = FastAPI(title="ATX Base Subagent API")

_TIMEOUT = 28


def get_subagent() -> BaseSubagent:
    """Dependency to get the subagent instance."""
    if not hasattr(app.state, "subagent") or app.state.subagent is None:
        raise HTTPException(status_code=500, detail="Subagent is not initialized")
    return app.state.subagent


@app.get("/ping")
async def ping():
    """Health check endpoint."""
    return {"status": "ok"}


@app.post("/invocations")
async def send_notification(request: Dict[str, str]) -> Dict[str, str]:
    """Handle notification invocations from the platform."""
    # TODO
    logger.info("Notification received by the subagent")
    return {"message": "Notification received by the subagent"}


@app.post("/message/send")
async def send_message(request: InvocationRequest, subagent: BaseSubagent = Depends(get_subagent)):
    """
    Process a message request and return the agent's response.

    This endpoint passes the input to the agent and returns the response.
    """

    if subagent is None:
        logger.error("Subagent is not initialized")
        return SendMessageOutput(
            error=A2AError(
                code=A2AErrorCode.INTERNAL_ERROR,
                message="Subagent is not initialized",
            )
        )

    context_id: str | None = None

    try:
        logger.info("Message request received by the subagent")

        # Extract message information
        user_id, sender, context_id, parts = extract_message_info(request)

        logger.info("Processing message")
        logger.debug(f"Message: {json.dumps(parts)}")

        # Process message with subagent with timeout
        subagent_response = await asyncio.wait_for(
            asyncio.to_thread(subagent.process_message, json.dumps(parts)), timeout=_TIMEOUT
        )

        extracted_subagent_response = extract_text_from_strands_agent_response(subagent_response)

        return convert_subagent_response_to_send_message_output(
            context_id, request.message, response=extracted_subagent_response
        )

    except asyncio.TimeoutError:
        logger.error(f"Subagent processing timed out after {_TIMEOUT} seconds")
        return convert_subagent_response_to_send_message_output(
            context_id,
            request.message,
            error_message="I was not able to generate a response on time.",
        )

    except Exception as e:
        logger.error(f"Error processing message: {str(e)}")
        return convert_subagent_response_to_send_message_output(
            context_id, request.message, error_message=f"Error processing message: {str(e)}"
        )


def start_subagent_api_server(
    subagent_instance: BaseSubagent,
    host: str = "0.0.0.0",
    port: int = 8080,
):
    """Start the FastAPI server."""
    logger.info(f"Starting Subagent API server on {host}:{port}")

    app.state.subagent = subagent_instance

    uvicorn.run(app, host=host, port=port)
