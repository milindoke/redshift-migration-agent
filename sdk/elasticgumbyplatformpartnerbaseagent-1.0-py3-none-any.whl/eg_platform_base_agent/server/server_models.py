"""Server models for agent runtime."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AgentRuntimeContext:
    """Agent runtime context containing workspace, job, and instance identifiers."""

    workspace_id: str
    job_id: str
    agent_instance_id: str
    initial_auth_token: Optional[str] = None
