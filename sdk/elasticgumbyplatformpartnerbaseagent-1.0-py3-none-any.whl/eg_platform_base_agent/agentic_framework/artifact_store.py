"""
Artifact storage management for agentic framework.
"""

import logging
from typing import Optional

from eg_platform_base_agent.agentic_framework.agentic_api_helper import AgenticApiHelper
from eg_platform_base_agent.agentic_framework.api_model import CategoryType, Visibility
from eg_platform_base_agent.agentic_framework.common import (
    download_from_presigned_url,
    upload_from_presigned_url,
)

logger = logging.getLogger(__name__)


class ArtifactStore(AgenticApiHelper):
    """Manages artifact storage operations."""

    def __init__(self, **kwargs):
        """Initialize ArtifactStore."""
        super().__init__(**kwargs)

    def list_artifacts(
        self, agent_instance_id: str, category: Optional[CategoryType] = None
    ) -> Optional[dict]:
        """List artifacts by agent instance ID and category type."""
        agent_filter = {"agentInstanceId": agent_instance_id}
        if category is not None:
            agent_filter["category"] = category.value
        try:
            request_data = {"artifactFilter": {"agentFilter": agent_filter}}

            request = self._inject_request_context(request_data)
            return self.client.list_artifacts(**request)

        except Exception:
            category_str = category.value if category else None
            logger.error(
                f"Error listing artifacts for agent {agent_instance_id} with category {category_str}"
            )
            raise

    def upload_artifact(
        self,
        content: bytes,
        digest: str,
        artifact_id: Optional[str] = None,
        category_type: Optional[str] = None,
        file_type: Optional[str] = None,
        plan_step_id: Optional[str] = None,
        label: Optional[str] = None,
    ) -> Optional[str]:
        """Upload artifact with specified category. Returns artifactId."""
        try:
            # Validate exactly one is provided
            if artifact_id is None and (category_type is None and file_type is None):
                raise ValueError(
                    "Either artifact_id or category_type and file_type must be provided"
                )
            if artifact_id is not None and (category_type is not None or file_type is not None):
                raise ValueError("Cannot provide both artifact_id and category_type or file_type")

            request_data = {
                "contentDigest": {"sha256": digest},
                "visibility": Visibility.INTERNAL,
            }

            if artifact_id is not None:
                request_data["artifactReference"] = {"artifactId": str(artifact_id)}
            else:  # artifact_type is not None
                request_data["artifactReference"] = {
                    "artifactType": {
                        "categoryType": str(category_type),
                        "fileType": str(file_type),
                    }
                }

            if plan_step_id:
                request_data["planStepId"] = plan_step_id
            if label:
                request_data["label"] = label

            request = self._inject_request_context(request_data)
            upload_response = self.client.create_artifact_upload_url(**request)

            if upload_response:
                upload_from_presigned_url(upload_response, content)
                complete_artifact_upload_req = {"artifactId": upload_response.get("artifactId")}
                self.client.complete_artifact_upload(
                    **self._inject_request_context(complete_artifact_upload_req)
                )
                return upload_response.get("artifactId")
            return None

        except Exception:
            logger.error("Error uploading artifact")
            raise

    def download_artifact(self, artifact_id: str, destination_file_path: str) -> None:
        """Download artifact by ID and put to the destination file path"""
        try:
            request_data = {"artifactId": artifact_id}

            request = self._inject_request_context(request_data)
            download_response = self.client.create_artifact_download_url(**request)
            download_from_presigned_url(download_response, destination_file_path)
            logger.info(
                f"Download artifactId[{artifact_id}] to {destination_file_path} successfully"
            )
        except Exception:
            logger.error(f"Error downloading artifact {artifact_id}")
            raise
