"""
Common utilities for agentic framework.
"""

import base64
import hashlib
import logging
import os
from dataclasses import dataclass

import requests
from botocore.exceptions import ClientError
from requests.adapters import HTTPAdapter

logger = logging.getLogger(__name__)


@dataclass
class InternalServerException(Exception):
    """Internal server exception."""

    message: str

    def __post_init__(self):
        super().__init__(self.message)

    def to_dict(self):
        return {"message": self.message}


def calculate_digest(content: bytes) -> str:
    try:
        sha256_hash = hashlib.sha256(content).digest()

        # Encode the hash to base64
        base64_encoded = base64.b64encode(sha256_hash).decode("utf-8")
        return base64_encoded
    except Exception as e:
        logger.error(f"Error calculating checksum: {str(e)}")
        raise


def upload_from_presigned_url(create_upload_url_response, content: bytes):
    try:
        presigned_url_string = create_upload_url_response["s3preSignedUrl"]
        headers = {
            key: value[0] for key, value in create_upload_url_response["requestHeaders"].items()
        }

        with requests.Session() as session:
            session.mount("https://", HTTPAdapter(max_retries=3))
            upload_response = session.put(presigned_url_string, data=content, headers=headers)

        if upload_response.status_code == 200:
            logger.info("File uploaded successfully!")
        else:
            logger.error(f"File upload failed. Status code: {upload_response.status_code}")
            logger.error(f"File upload failed. Response: {upload_response.text}")
            raise InternalServerException("Artifact upload failure")
    except requests.exceptions.ConnectionError as connection_error:
        logger.error(f"File upload failed due to connection error {str(connection_error)!r}")
        raise InternalServerException("Artifact upload failed due to connection errors.")


def download_from_presigned_url(download_upload_url_response, destination_file_path: str):
    try:
        presigned_url_string = download_upload_url_response["s3preSignedUrl"]
        headers = {
            key: value[0] for key, value in download_upload_url_response["requestHeaders"].items()
        }

        with requests.Session() as session:
            session.mount("https://", HTTPAdapter(max_retries=3))
            download_response = session.get(presigned_url_string, headers=headers)

        dir_name = os.path.dirname(destination_file_path)
        if dir_name:
            os.makedirs(dir_name, exist_ok=True)
        with open(destination_file_path, "wb") as downloaded_file:
            downloaded_file.write(download_response.content)
            logger.info(f"File downloaded to {destination_file_path} successfully")
    except requests.exceptions.ConnectionError as connection_error:
        logger.error(
            f"File downloaded to {destination_file_path} failed due to connection error {str(connection_error)!r}"
        )
        raise InternalServerException("Artifact download failed due to connection errors.")
    except Exception:
        logger.error(f"File downloaded to {destination_file_path} failed due to unexpected error")
        raise


def handle_boto_error(error: ClientError) -> None:
    """Handle boto3 client errors."""
    error_code = error.response["Error"]["Code"]
    error_message = error.response["Error"]["Message"]
    logger.error(f"AgenticApi Error: {error_code} - {error_message}")
    raise error
