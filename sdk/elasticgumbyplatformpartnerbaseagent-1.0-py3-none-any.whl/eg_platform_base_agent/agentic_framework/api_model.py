"""
API models for agentic framework - minimal implementation for checkpointing.
"""

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import Generic, TypeVar

import mypy_boto3_elasticgumbyagenticservice.type_defs as eg

T = TypeVar("T", bound=Mapping)


class CategoryType(str, Enum):
    """Artifact category types."""

    STATE = "STATE"


class FileType(str, Enum):
    """File types for artifacts."""

    JSON = "JSON"
    ZIP = "ZIP"


class Visibility(str, Enum):
    """Artifact visibility levels."""

    INTERNAL = "INTERNAL"


class ApiShapeMixin(Generic[T]):
    """Base mixin for API request/response shapes."""

    def to_dict(self) -> T:
        """
        Converting dataclass to AgenticAPI requests expected format.
        """
        raise NotImplementedError("Perhaps you forgot to implement this method?")


@dataclass(frozen=True)
class AgenticApiRequestContext(ApiShapeMixin[eg.RequestContextTypeDef]):
    """
    Request context for Elastic Gumby Agentic API calls.
    Contains job metadata and agent identification information.
    """

    job_id: str
    workspace_id: str
    agent_instance_id: str
    authorization_token: str = field(repr=False)

    def to_dict(self) -> eg.RequestContextTypeDef:
        """
        Convert to dictionary format expected by the API.
        """
        return {
            "jobMetadata": {"jobId": self.job_id, "workspaceId": self.workspace_id},
            "agentInstanceId": self.agent_instance_id,
            "authorizationToken": self.authorization_token,
        }
