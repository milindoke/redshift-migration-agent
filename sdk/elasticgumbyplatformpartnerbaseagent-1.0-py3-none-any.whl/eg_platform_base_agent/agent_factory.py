"""
Agent factory functions for creating orchestrator instances.
"""

import logging
import os
from typing import Any, Optional, TypeVar, Union

from strands.models.model import Model
from strands.tools.mcp.mcp_client import MCPClient

from eg_platform_base_agent.base_subagent.base_subagent import AsyncBaseSubagent, BaseSubagent
from eg_platform_base_agent.memory.episodic_memory import EpisodicMemory
from eg_platform_base_agent.memory.file_memory_repository import FileSystemRepository
from eg_platform_base_agent.memory.memory_manager import MemoryManager
from eg_platform_base_agent.orchestrator_strands.base_orchestrator import (
    AsyncBaseOrchestrator,
    BaseOrchestrator,
)
from eg_platform_base_agent.orchestrator_strands.conversation.file_repository import (
    FileMultiSourceConversationRepository,
)
from eg_platform_base_agent.orchestrator_strands.hooks.conversation_hook_provider import (
    ConversationHookProvider,
)
from eg_platform_base_agent.orchestrator_strands.hooks.memory_hook_provider import (
    MemoryHookProvider,
)
from eg_platform_base_agent.orchestrator_strands.tools.memory_tool import MemoryTool
from eg_platform_base_agent.orchestrator_strands.tools.send_message_tools import SendMessageTools
from eg_platform_base_agent.orchestrator_strands.tools.subagent_registry_tools import (
    SubagentRegistryTools,
)
from eg_platform_base_agent.utils import get_prompt_with_name

OrchestratorT = TypeVar("OrchestratorT", BaseOrchestrator, AsyncBaseOrchestrator)
SubagentT = TypeVar("SubagentT", BaseSubagent, AsyncBaseSubagent)

logger = logging.getLogger(__name__)


def _create_default_orchestrator(
    agent_class: type[OrchestratorT],
    mcp_client: Optional[MCPClient] = None,
    storage_dir: str = "/tmp/orchestrator_agent",
    system_prompt: Optional[str] = None,
    *,
    with_subagent: bool = False,
    additional_custom_tools: Optional[list[Any]] = None,
    model_id: str = "anthropic.claude-3-5-sonnet-20240620-v1:0",
    model: Union[Model, str, None] = None,
) -> OrchestratorT:
    logger.info("Creating default orchestrator with full feature set")

    custom_tools: list[Any] = []

    # Create memory components
    memory_storage_path = os.path.join(storage_dir, "memories")
    repository = FileSystemRepository(storage_path=memory_storage_path)
    episodic_memory = EpisodicMemory(repository=repository)
    memory_manager = MemoryManager(memories=[episodic_memory])

    # Create memory tool
    memory_tool = MemoryTool(memory_manager)
    custom_tools.append(memory_tool.memory)

    if with_subagent:
        # Create subagent discovery tool
        subagent_registry_tools = SubagentRegistryTools()
        custom_tools.append(subagent_registry_tools.discover_subagents)

        # Create send message to subagent tool
        send_message_tools = SendMessageTools()
        custom_tools.append(send_message_tools.send_message_to_subagent)

    # Add any additional custom tools provided by caller
    if additional_custom_tools:
        custom_tools.extend(additional_custom_tools)

    # Create conversation repository
    conversation_repository = FileMultiSourceConversationRepository(storage_dir=storage_dir)

    # Create hooks
    hooks = [
        ConversationHookProvider(repository=conversation_repository),
        MemoryHookProvider(memory_manager=memory_manager),
    ]

    # Use provided system prompt or default
    if system_prompt is None:
        system_prompt = get_prompt_with_name("test_orchestrator_prompt")

    # Create orchestrator with explicit hooks
    orchestrator = agent_class(
        system_prompt=system_prompt,
        hooks=hooks,
        mcp_clients=[mcp_client] if mcp_client is not None else None,
        region_name=os.getenv("AWS_REGION") or "us-east-1",
        custom_tools=custom_tools,
        model_id=model_id,
        model=model,
    )

    logger.info("Default orchestrator created successfully with memory and conversation support")
    return orchestrator


def create_default_orchestrator(
    mcp_client: Optional[MCPClient] = None,
    storage_dir: str = "/tmp/orchestrator_agent",
    system_prompt: Optional[str] = None,
    custom_tools: Optional[list[Any]] = None,
    model_id: str = "anthropic.claude-3-5-sonnet-20240620-v1:0",
    model: Union[Model, str, None] = None,
) -> BaseOrchestrator:
    """
    Create a BaseOrchestrator instance with full memory and conversation support.

    This function creates a fully-featured orchestrator with:
    - Episodic memory for storing agent experiences
    - Conversation tracking across multiple sources
    - Memory tools for agent self-reflection
    - Lifecycle hooks for conversation and memory events

    If your application has a running asyncio event loop, then use create_default_async_orchestrator
    instead. See BaseOrchestrators's documentation.

    Args:
        mcp_client: Optional MCP client for tool integration
        storage_dir: Directory for agent data storage
        system_prompt: Custom system prompt, defaults to test_orchestrator_prompt
        custom_tools: Optional list of additional custom tools to add to the orchestrator
        model_id: Optional model ID for Bedrock inference
        model: Optional Strands Model instance or model ID string (takes precedence over model_id)

    Returns:
        Configured BaseOrchestrator instance with memory, hooks, and tools
    """
    return _create_default_orchestrator(
        BaseOrchestrator,
        mcp_client,
        storage_dir,
        system_prompt,
        additional_custom_tools=custom_tools,
        model_id=model_id,
        model=model,
    )


def create_default_async_orchestrator(
    mcp_client: Optional[MCPClient] = None,
    storage_dir: str = "/tmp/orchestrator_agent",
    system_prompt: Optional[str] = None,
    custom_tools: Optional[list[Any]] = None,
    model_id: str = "anthropic.claude-3-5-sonnet-20240620-v1:0",
    model: Union[Model, str, None] = None,
) -> AsyncBaseOrchestrator:
    """Create a AsyncBaseOrchestrator instance with full memory and conversation support.

    This function creates a fully-featured orchestrator with:
    - Episodic memory for storing agent experiences
    - Conversation tracking across multiple sources
    - Memory tools for agent self-reflection
    - Lifecycle hooks for conversation and memory events

    Args:
        mcp_client: Optional MCP client for tool integration
        storage_dir: Directory for agent data storage
        system_prompt: Custom system prompt, defaults to test_orchestrator_prompt
        custom_tools: Optional list of additional custom tools to add to the orchestrator
        model_id: Optional model ID for Bedrock inference
        model: Optional Strands Model instance or model ID string (takes precedence over model_id)

    Returns:
        Configured AsyncBaseOrchestrator instance with memory, hooks, and tools
    """
    return _create_default_orchestrator(
        AsyncBaseOrchestrator,
        mcp_client,
        storage_dir,
        system_prompt,
        additional_custom_tools=custom_tools,
        model_id=model_id,
        model=model,
    )


def create_default_orchestrator_with_subagent(
    system_prompt: str,
    mcp_client: Optional[MCPClient] = None,
    storage_dir: str = "/tmp/orchestrator_agent",
    custom_tools: Optional[list[Any]] = None,
    model_id: str = "anthropic.claude-3-5-sonnet-20240620-v1:0",
    model: Union[Model, str, None] = None,
) -> BaseOrchestrator:
    """Create a BaseOrchestrator instance with full memory and conversation support and subagent tools.

    This function creates a fully-featured orchestrator with:
    - Episodic memory for storing agent experiences
    - Conversation tracking across multiple sources
    - Memory tools for agent self-reflection
    - Lifecycle hooks for conversation and memory events
    - Subagent tools for communication and discovery (mocked)

    If your application has a running asyncio event loop, then use
    create_default_async_orchestrator_with_subagent instead. See BaseOrchestrator's documentation.

    Args:
        mcp_client: Optional MCP client for tool integration
        storage_dir: Directory for agent data storage
        system_prompt: Custom system prompt, defaults to test_orchestrator_prompt
        custom_tools: Optional list of additional custom tools to add to the orchestrator
        model_id: Optional model ID for Bedrock inference
        model: Optional Strands Model instance or model ID string (takes precedence over model_id)

    Returns:
        Configured BaseOrchestrator instance with memory, hooks, and tools
    """
    return _create_default_orchestrator(
        BaseOrchestrator,
        mcp_client,
        storage_dir,
        system_prompt,
        with_subagent=True,
        additional_custom_tools=custom_tools,
        model_id=model_id,
        model=model,
    )


def create_default_async_orchestrator_with_subagent(
    system_prompt: str,
    mcp_client: Optional[MCPClient] = None,
    storage_dir: str = "/tmp/orchestrator_agent",
    custom_tools: Optional[list[Any]] = None,
    model_id: str = "anthropic.claude-3-5-sonnet-20240620-v1:0",
    model: Union[Model, str, None] = None,
) -> AsyncBaseOrchestrator:
    """Create a AsyncBaseOrchestrator instance with full memory and conversation support and subagent tools.

    This function creates a fully-featured orchestrator with:
    - Episodic memory for storing agent experiences
    - Conversation tracking across multiple sources
    - Memory tools for agent self-reflection
    - Lifecycle hooks for conversation and memory events
    - Subagent tools for communication and discovery (mocked)

    Args:
        mcp_client: Optional MCP client for tool integration
        storage_dir: Directory for agent data storage
        system_prompt: Custom system prompt, defaults to test_orchestrator_prompt
        custom_tools: Optional list of additional custom tools to add to the orchestrator
        model_id: Optional model ID for Bedrock inference
        model: Optional Strands Model instance or model ID string (takes precedence over model_id)

    Returns:
        Configured AsyncBaseOrchestrator instance with memory, hooks, and tools
    """
    return _create_default_orchestrator(
        AsyncBaseOrchestrator,
        mcp_client,
        storage_dir,
        system_prompt,
        with_subagent=True,
        additional_custom_tools=custom_tools,
        model_id=model_id,
        model=model,
    )


def _create_default_subagent(
    agent_class: type[SubagentT],
    system_prompt: str,
    mcp_client: Optional[MCPClient] = None,
    model: Union[Model, str, None] = None,
) -> SubagentT:
    logger.info("Creating default subagent with minimal configuration")

    # Create subagent with minimal configuration
    subagent = agent_class(
        system_prompt=system_prompt,
        mcp_clients=[mcp_client] if mcp_client is not None else None,
        region_name=os.getenv("AWS_REGION") or "us-east-1",
        model=model,
    )

    logger.info("Default subagent created successfully")
    return subagent


def create_default_subagent(
    system_prompt: str,
    mcp_client: Optional[MCPClient] = None,
    model: Union[Model, str, None] = None,
) -> BaseSubagent:
    """Create a BaseSubagent instance with minimal configuration.

    This function creates a lightweight subagent without memory or conversation tracking.

    If your application has a running asyncio event loop, then use create_default_async_subagent
    instead. See BaseSubagent's documentation.

    Args:
        mcp_client: Optional MCP client for tool integration
        system_prompt: Custom system prompt, defaults to simple assistant prompt
        model: Optional Strands Model instance or model ID string

    Returns:
        Configured BaseSubagent instance
    """
    return _create_default_subagent(BaseSubagent, system_prompt, mcp_client, model)


def create_default_async_subagent(
    system_prompt: str,
    mcp_client: Optional[MCPClient] = None,
    model: Union[Model, str, None] = None,
) -> AsyncBaseSubagent:
    """Create an AsyncBaseSubagent instance with minimal configuration.

    This function creates a lightweight subagent without memory or conversation tracking.

    Args:
        mcp_client: Optional MCP client for tool integration
        system_prompt: Custom system prompt, defaults to simple assistant prompt
        model: Optional Strands Model instance or model ID string

    Returns:
        Configured AsyncBaseSubagent instance
    """
    return _create_default_subagent(AsyncBaseSubagent, system_prompt, mcp_client, model)
