#!python
"""
Test script for AsyncMCPClient supporting both SSE and stdio modes.
"""

import argparse
import asyncio
import logging
import os

from eg_mcp_client.async_mcp_client import AsyncMCPClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


async def test_sse_connection(
    url: str, headers: dict = None, timeout: float = 5, sse_read_timeout: float = 300
):
    """Test connection to an MCP server via SSE."""
    client = AsyncMCPClient()
    try:
        await client.connect_via_sse(
            server_url=url, headers=headers, timeout=timeout, sse_read_timeout=sse_read_timeout
        )

        # Print available tools in a more readable format
        logger.info("Available tools:")
        if client.tools:
            for i, tool in enumerate(client.tools, 1):
                logger.info(f"  {i}. {tool}")
        else:
            logger.info("  No tools available")

        # Print available prompts in a more readable format
        logger.info("Available prompts:")
        if client.prompts:
            for i, prompt in enumerate(client.prompts, 1):
                logger.info(f"  {i}. {prompt}")
        else:
            logger.info("  No prompts available")

        # Here you can add additional test code to call specific tools

    finally:
        await client.close()


async def test_stdio_connection(
    command: str, args: list = None, env: dict = None, working_dir: str = None
):
    """Test connection to an MCP server via stdio."""
    client = AsyncMCPClient()
    try:
        await client.connect_via_stdio(
            command=command, args=args, env=env, working_directory=working_dir
        )

        # Print available tools in a more readable format
        logger.info("Available tools:")
        if client.tools:
            for i, tool in enumerate(client.tools, 1):
                logger.info(f"  {i}. {tool.name} {tool.description}")
                logger.info(f"  {tool.input_schema}")
        else:
            logger.info("  No tools available")

        # Print available prompts in a more readable format
        logger.info("Available prompts:")
        if client.prompts:
            for i, prompt in enumerate(client.prompts, 1):
                logger.info(f"  {i}. {prompt}")
        else:
            logger.info("  No prompts available")

        # Demonstrate tool calling
        result = client.call_tool("get_job")
        await result
        logger.info(f"   {result}")

    finally:
        await client.close()


async def main():
    parser = argparse.ArgumentParser(
        description="Run AsyncMCPClient to test MCP server connections"
    )

    # Create subparsers for different connection types
    subparsers = parser.add_subparsers(dest="connection_type", help="Connection type")

    # SSE connection parser
    sse_parser = subparsers.add_parser("sse", help="Connect via SSE")
    sse_parser.add_argument("--url", required=True, help="URL of the MCP server")
    sse_parser.add_argument("--header", action="append", help="Headers in format key:value")
    sse_parser.add_argument(
        "--timeout", type=float, default=5, help="Connection timeout in seconds"
    )
    sse_parser.add_argument(
        "--sse-read-timeout", type=float, default=300, help="SSE read timeout in seconds"
    )

    # Stdio connection parser
    stdio_parser = subparsers.add_parser("stdio", help="Connect via stdio")
    stdio_parser.add_argument("--command", required=True, help="Command to execute")
    stdio_parser.add_argument("--args", help="Command arguments as a space-separated string")
    stdio_parser.add_argument(
        "--arg", action="append", help="Individual command argument (can be used multiple times)"
    )
    stdio_parser.add_argument("--working-dir", help="Working directory")

    args = parser.parse_args()

    if args.connection_type == "sse":
        # Parse headers
        headers = {}
        if args.header:
            for header in args.header:
                key, value = header.split(":", 1)
                headers[key.strip()] = value.strip()

        await test_sse_connection(
            url=args.url,
            headers=headers if headers else None,
            timeout=args.timeout,
            sse_read_timeout=args.sse_read_timeout,
        )

    elif args.connection_type == "stdio":
        command_args = []
        if args.args:
            command_args.extend(args.args.split())
        if args.arg:
            command_args.extend(args.arg)

        await test_stdio_connection(
            command=args.command,
            args=command_args,
            env=os.environ.copy(),
            working_dir=args.working_dir,
        )

    else:
        parser.print_help()


if __name__ == "__main__":
    asyncio.run(main())
