import logging

from mcp.server.fastmcp import FastMCP

# Configure logging
logger = logging.getLogger(__name__)

# Create the FastMCP server instance
mcp = FastMCP("atx-agentic-mcp-server")
