"""
Client utilities for the ElasticGumbyAgenticAPI.

This module provides utility functions for creating and configuring
boto3 clients for the ElasticGumbyAgenticAPI.
"""

import functools
import logging
import os
from typing import Optional

import boto3
from botocore.client import BaseClient
from botocore.config import Config as BotocoreConfig

from elastic_gumby_agentic_mcp import env_var

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    filename="/tmp/atx-mcp-server.log",  # Log to file to avoid interfering with stdio
)
logger = logging.getLogger(__name__)

ATX_AGENTIC_API_SERVICE_NAME = "elasticgumbyagenticservice"


@functools.lru_cache(maxsize=1)
def atx_agenticapi_client() -> BaseClient:
    return create_atx_agenticapi_client()


def create_atx_agenticapi_client(
    endpoint_url: Optional[str] = None,
    region: Optional[str] = None,
    isengard_credentials: Optional[tuple[str, str]] = None,
    max_retries: int = 3,
    timeout: int = 30,
) -> BaseClient:
    """
    Create a boto3 client for the ElasticGumbyAgenticAPI.

    Args:
        endpoint_url: Custom endpoint URL (defaults to environment variable or standard endpoint)
        region: AWS region (defaults to environment variable or us-west-2)
        max_retries: Maximum number of retries for API calls
        timeout: Timeout in seconds for API calls

    Returns:
        A configured boto3 client
    """
    # Get region from environment or use default
    region = region or os.environ.get("AWS_REGION", "us-east-1")

    # Get endpoint URL from environment or use default
    endpoint_url = endpoint_url or os.environ[env_var.ENV_KEY_QT_AGENTIC_API_ENDPOINT]

    # Create a botocore config with retries and timeouts
    boto_config = BotocoreConfig(
        retries={"max_attempts": max_retries, "mode": "standard"},
        connect_timeout=timeout,
        read_timeout=timeout,
    )

    if not isengard_credentials:
        account_id = os.getenv("ISENGARD_ACCOUNT")
        role_name = os.getenv("ISENGARD_ROLE")
        if account_id and role_name:
            isengard_credentials = (account_id, role_name)

    if isengard_credentials:
        # Only import isengard if parameter is supplied. That way, BenderLibIsengard can be provided by consuming
        # packages and only needs to be a test dependency here.
        import isengard

        account_id, role_name = isengard_credentials
        isengard_client = isengard.Client()
        session = isengard_client.get_boto3_session(
            account_id,
            role_name,
            region=region,
        )
        client = session.client(
            service_name=ATX_AGENTIC_API_SERVICE_NAME,
            region_name=region,
            endpoint_url=endpoint_url,
            config=boto_config,
        )
    else:
        # Create and return the boto3 client
        client = boto3.client(
            service_name=ATX_AGENTIC_API_SERVICE_NAME,
            region_name=region,
            endpoint_url=endpoint_url,
            config=boto_config,
        )

    logger.info(
        f"Client created, service: {ATX_AGENTIC_API_SERVICE_NAME}, region: {region}, endpoint: {endpoint_url}"
    )

    return client
