"""ElasticGumbyAgenticMCP module."""
